#include<stdio.h>
#include<string.h>
int main(){
char str1[40];
char str2[40];
char str3[80];
int i,j;
printf("enter a string 1 : ");
gets(str1);
printf("enter a string 2 : ");
gets(str2);

for(i=0;str1[i]!=0;i++)
{
    str3[i]=str1[i];
}
//---------for adding space-----
str3[i]=' ';
i++;
for(j=0;str1[j]!=0;j++)
{
    str3[i]=str2[j];
    i++;
}
str3[i]='\0';
puts(str3);
return 0;
}

