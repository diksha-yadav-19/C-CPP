#include<iostream>
using namespace std;

class Radius{
    int radius;
    public:
void setradius(int r){
    radius=r;
}
int getradius(){
    return radius;
}
friend class Process;
};
class Height{
    int height;
    public:
void setheight(int h){
    height=h;
}
int getheight (){
    return height;
}
friend class Process;
};
class Process{
    public:
    void Volume(Radius r,Height h){
        int volume=3.14*r.getradius()*r.getradius()*h.getheight();
        cout<<"Volume of Cyclinder is : "<<volume;
    }
};
int main(){
    Radius r;
    r.setradius(10);
    Height h;
    h.setheight(15);
    Process p;
    p.Volume(r,h);
}