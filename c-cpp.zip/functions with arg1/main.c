#include <stdio.h>
#include <math.h>

int main() {
    float cylinderVolume(float radius, float height); // Function prototype for cylinder volume
    float coneVolume(float radius, float height); // Function prototype for cone volume

    float radius_cylinder, height_cylinder;
    float radius_cone, height_cone;

    printf("Enter the radius of the cylinder: ");
    scanf("%f", &radius_cylinder);

    printf("Enter the height of the cylinder: ");
    scanf("%f", &height_cylinder);

    float cylinderVol = cylinderVolume(radius_cylinder, height_cylinder);
    printf("Volume of the cylinder: %f\n", cylinderVol);

    printf("Enter the radius of the cone: ");
    scanf("%f", &radius_cone);

    printf("Enter the height of the cone: ");
    scanf("%f", &height_cone);

    float coneVol = coneVolume(radius_cone, height_cone);
    printf("Volume of the cone: %f\n", coneVol);

    return 0;
}

float cylinderVolume(float radius, float height) {
    float V = 3.14 * pow(radius, 2) * height;
    return V;
}

float coneVolume(float radius, float height) {
    float CV = (1.0 / 3.0) * 3.14 * pow(radius, 2) * height;
    return CV;
}

