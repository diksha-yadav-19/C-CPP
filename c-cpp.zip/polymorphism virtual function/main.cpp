
// With virtual function
#include <iostream>

using namespace std;

class Polygon {
    protected: 
    int height,width;
    public: 
    void setvalues(int x, int y) {
        width = x;
        height = y;
    }
    virtual int area() {
        return 0;
    }
};

class Rectangle: public Polygon {
    public: 
    int area() {
        return width * height;
    }
};

class Triangle: public Polygon 
{
    public: 
    int area() {
        return (width * height / 2);

    }
};

int main() {
    Rectangle rect;
    Triangle trgl;
    Polygon poly;

    Polygon * ptr1 = & rect;
    Polygon * ptr2 = & trgl;
    Polygon * ptr3 = & poly;

    ptr1 -> setvalues(10, 20);
    ptr2 -> setvalues(10, 20);
    ptr3 -> setvalues(10, 20);

    cout << "Area of Rectangle is: " << ptr1 -> area() << '\n';
    cout << "Area of Triangle is: " << ptr2 -> area() << '\n';
    cout << "Area of Polygon is: " << ptr3 -> area() << '\n';
    return 0;
}
