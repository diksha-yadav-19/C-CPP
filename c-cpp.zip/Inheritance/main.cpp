
#include <iostream>

using namespace std;

class LIB{
    public:
    float getsquare(float r){
        return(r*r);
    }
};
class CIRCLE:public LIB {
    float ar;
    public:
    void area(float r){
        ar=getsquare(r)*3.14;
        cout<<ar;
    }
};

int main()
{
   CIRCLE cobj;
   cobj.area(10);
}