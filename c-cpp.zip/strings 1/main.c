//--------------------copy one string to another---------------
#include<stdio.h>

int main() {
    char str1[40];
    char str2[40];
    printf("Enter a string: ");
    gets(str1);

    int i;
    for (i = 0; str1[i] != '\0'; i++) {
        str2[i] = str1[i];
    }
    str2[i] = '\0';
printf("Enter a repeated string: ");
    puts(str2);

    return 0;
}
