#include <stdio.h>


int main() {
    void findMin(int *p, int N, int *min);
    int N;
    printf("Enter the size of the array: ");
    scanf("%d", &N);

    int A[N];
    printf("Enter the elements of the array:\n");
    for (int i = 0; i < N; i++) {
        scanf("%d", &A[i]);
    }

    int minimum;
    findMin(&A[0], N, &minimum);
    printf("The minimum element in the array is: %d\n", minimum);
}

void findMin(int *p, int N, int *min) {
    *min = *p;
    for (int i = 0; i < N; i++) {
        if (*(p + i) < *min) {
            *min = *(p + i);
        }
    }
}




