#include <stdio.h>

int main() {
    int N;
    printf("Enter N: ");
    scanf("%d", &N);

   
    int A[N], B[N], C[N];

  
    printf("Enter values for array A:\n");
    for (int i = 0; i < N; i++) {
        printf("Enter value at A[%d]: ", i);
        scanf("%d", &A[i]);
    }

  
    printf("Enter values for array B:\n");
    for (int i = 0; i < N; i++) {
        printf("Enter value at B[%d]: ", i);
        scanf("%d", &B[i]);
    }
     printf("Sum of Two Arrays is:\n");

    
    for (int i = 0; i < N; i++) {
        C[i] = A[i] + B[i];
          printf("C[%d]: %d\n", i, C[i]);
    }
    return 0;
}
