#include<iostream>
using namespace std;

class Bank {
    float bal;

public:
    Bank() {
        bal = 10000; // Constructor
    }

    Bank(float b) {
        bal = b;
    }

    void show() {
        cout << "Balance is: " << bal << endl;
    }

    Bank(const Bank& robj) {
        bal = robj.bal;
    }

    ~Bank() {
        cout << "Destructor called for balance: " << bal << endl;
    }
};

int main() {
    Bank amnobj;
    amnobj.show();

    Bank rmnobj(8100.82);
    rmnobj.show();

    Bank chmnobj(rmnobj);
    chmnobj.show();

    return 0;
}

