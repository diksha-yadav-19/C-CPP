#include <stdio.h>

int main()
{
    int N, r, c;
    printf("Enter the number: ");
    scanf("%d", &N);

    int A[N][N];  // Declare the array after reading N

    for (r = 0; r < N; r++)
    {
        for (c = 0; c < N; c++)
        {
            if (c == N - 1 - r || r == c)
            {
                printf("Enter the value of A[%d][%d]: ", r, c);
                scanf("%d", &A[r][c]);
            }
            else
            {
                A[r][c] = 0;
            }
        }
    }

    printf("Resulting array:\n");
    for (r = 0; r < N; r++)
    {
        for (c = 0; c < N; c++)
        {
            printf("%d ", A[r][c]);
        }
        printf("\n");
    }

    return 0;
}
