#include <stdio.h>


int main() {
    void findMax(int *p, int N, int *max);
    int N;
    printf("Enter the size of the array: ");
    scanf("%d", &N);

    int A[N];
    printf("Enter the elements of the array:\n");
    for (int i = 0; i < N; i++) {
        scanf("%d", &A[i]);
    }

    int maximum;
    findMax(&A[0], N, &maximum);
    printf("The greatest element in the array is: %d\n", maximum);
}

void findMax(int *p, int N, int *max) {
    *max = *p;
    for (int i = 0; i < N; i++) {
        if (*(p + i) > *max) {
            *max = *(p + i);
        }
    }
}


