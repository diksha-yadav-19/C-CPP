
#include <stdio.h>

int main()
{
    printf("Hello Programmers\n\n");
    printf("\n Who are you?");
    printf("\t\t  I am a \"developer\"\n\n");
    printf("welcome to world of coding");
    
    return 0;
}
