#include <iostream>

using namespace std;

int main() 
{
    // allocating a new int ptr variable using new
    int* ptr = new int;
    *ptr = 5000;

    cout<<"value of pointer: "<<*ptr;

    // ptr memory deallocated using the delete operator
    delete ptr;

    cout<<"\nvalue now: "<<*ptr;
    return 0;
}
