//poro passing object returning object
#include<iostream>
using namespace std;
class Clock{
    int hours,minutes;
    public:
    void settime(int h,int m){
        hours=h;
        minutes=m;
    }
    void show(){
        cout<<hours<<" : "<<minutes<<endl;
    }
    Clock difference(Clock c){
        Clock diff;
        diff.hours=abs(hours-c.hours);
        diff.minutes=abs(minutes-c.minutes);
        return(diff);
    }
};
int main(){
  Clock clock1, clock2;

    clock1.settime(5, 30);
    clock2.settime(3, 45);

   Clock diffobj=clock2.difference(clock1);
   diffobj.show();
   

    return 0;
}