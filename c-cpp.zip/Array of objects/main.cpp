//Conectivity Example of Getter and Setter

#include<iostream>
using namespace std;

class STUDENT
{
	string name;
	int rollno;
	float cpp, java, dsa, total, per;
	
	public:	
		void input()
		{
			cout << "Enter name: ";
			cin >> name;
			cout << "Enter roll no.: ";
			cin >> rollno;
			cout << "Enter cpp, java and dsa marks out of 100: ";
			cin >> cpp >> java >> dsa;
		}
		
		void process()
		{
			total = cpp + java + dsa;
			per = (total)*100/300;
		}
	
		void show()
		{
			cout << "Name: " << name << "\nRoll No.: " << rollno << "\nTotal: " << total << 
			"\nPercentage: " << per << "%" << endl;
		}
		
		float getTotal()
		{
			return total;
		}
		
		float getPer()
		{
			return per;
		}
		
		int getRoll()
		{
			return rollno;
		}
};

int main()
{
	int n, i;
	cout << "Enter number of students: ";
	cin >> n;
	
	STUDENT s[n];
		
	for(i=0; i<n; i++)
	{
		cout << "\nSTUDENT " << i+1 << endl;
		s[i].input();
		s[i].process();
	}
	
	float maxTot, minPer;
	int maxRoll, minRoll;
	
	maxTot = s[0].getTotal();
	maxRoll = s[0].getRoll();
	minPer = s[0].getPer();
	minRoll = s[0].getRoll();
	
	cout << "\nRESULT CARD\n";
	for(i=0; i<n; i++)
	{
		cout << "\nSTUDENT " << i+1 << endl;
		s[i].show();
		
		if(s[i].getTotal() > maxTot)
		{
			maxTot = s[i].getTotal();
			maxRoll = s[i].getRoll();
		}
		
		if(s[i].getPer() < minPer)
		{
			minPer = s[i].getPer();
			minRoll = s[i].getRoll();
		}
	}
	
	cout << "Maximum total = " << maxTot <<endl;
	cout<<"Roll No.: " << maxRoll<<endl;
	cout << "Minimum percentage = " << minPer <<" % " <<endl;
	cout<<"Roll No.: " << minRoll<<endl;
	
}