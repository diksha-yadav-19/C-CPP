
#include <stdio.h>

int main()
{
    int i=10;
    while(i){
        printf("%d\n",i);
        i++;
    }
    printf("Hello world");

    return 0;
}
