#include <stdio.h>

int main()
{
    int r, c, ra, rb, ca, cb, sum;

    printf("Enter the number of rows and columns of matrix A: ");
    scanf("%d %d", &ra, &ca);

    printf("Enter the number of rows and columns of matrix B: ");
    scanf("%d %d", &rb, &cb);

    if (ca != cb || ra != rb) {
        printf("Invalid number of rows and columns for matrix addition.\n");
        return 0;
    }

    int A[ra][ca];

    for (r = 0; r < ra; r++) {
        for (c = 0; c < ca; c++) {
            printf("Enter the value at A[%d][%d]: ", r, c);
            scanf("%d", &A[r][c]);
        }
    }

    int B[rb][cb];

    for (r = 0; r < rb; r++) {
        for (c = 0; c < cb; c++) {
            printf("Enter the value at B[%d][%d]: ", r, c);
            scanf("%d", &B[r][c]);
        }
    }

    int C[ra][ca];  // Use ra and ca as dimensions for matrix C

    for (r = 0; r < ra; r++) {
        for (c = 0; c < ca; c++) {
            C[r][c] = A[r][c] + B[r][c];
        }
    }

    printf("\nAddition of matrices A and B:\n");

    for (r = 0; r < ra; r++) {
        for (c = 0; c < ca; c++) {
            printf("%d ", C[r][c]);
        }
        printf("\n");
    }

    return 0;
}



