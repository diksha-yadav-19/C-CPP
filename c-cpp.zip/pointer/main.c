
#include <stdio.h>

void main()
{
    int a=-11;
    const int *p=&a;
    *p=10; // error as p is const
    printf("%d",a);
    

    return 0;
}
