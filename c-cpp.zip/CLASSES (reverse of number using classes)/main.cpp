#include<iostream>
using namespace std;

class Reverse {
    int n, temp, rem, rev = 0;

public:
    void input() {
        cout << "enter a number :";
        cin >> n;
    }

    void calrev() {
        temp = n;
        while (temp != 0) {
            rem = temp % 10;
            rev = rev * 10 + rem;
            temp = temp / 10;
        }
    }

    void show() {
        cout << "reverse of the number is: " << rev << endl;
    }
};

int main() {
    Reverse obj;
    obj.input();
    obj.calrev();
    obj.show();
    return 0;
}

	


 
 
