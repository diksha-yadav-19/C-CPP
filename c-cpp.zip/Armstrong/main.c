#include <stdio.h>
#include <math.h>

int main()
{
    int r, n, sum = 0, temp;
    int count = 0;

    printf("Enter a number: ");
    scanf("%d", &n);

    temp = n;

    while (temp != 0) {
        temp = temp / 10;
        count++;
    }

    temp = n;

    while (temp != 0) {
        r = temp % 10;
        sum = sum + pow(r, count);
        temp = temp / 10;
    }

    if (n == sum) {
        printf("The number is an Armstrong number.\n");
    } else {
        printf("The number is not an Armstrong number.\n");
    }

    return 0;
}
