/******************************************************************************

GIVEN A NUMBER PRINT EVEN NUMBER UPTO THAT NUMBER

*******************************************************************************/
#include <iostream>
using namespace std;

void printEven(int n) {
    cout << "Even numbers up to " << n << " are: ";
    for (int i = 0; i <= n; i++) {
        if (i % 2 == 0) {
            cout << i << " ";
        }
    }
    cout << endl;
}

int main() {
    int number = 30;
    printEven(number);
    return 0;
}

