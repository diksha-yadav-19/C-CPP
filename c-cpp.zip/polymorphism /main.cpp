//polymorphism 
#include<iostream>
using namespace std;

class Rect{
    public:
    virtual void area(){
        cout<<"\n Area of rectangle";
    }
};
class Circle : public Rect{
    public:
    void area(){
        cout<<"\n Area of circle\n";
    }
};
int main(){
    Rect robj;  
    Rect *ptr;
    ptr = &robj;
    ptr->area();
    Circle cobj;
    ptr=&cobj;
    ptr->area(); // this pointer is actually of class Rect but calling function of derived class
}



