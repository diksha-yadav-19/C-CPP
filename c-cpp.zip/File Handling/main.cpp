#include<iostream>
#include<fstream>
using namespace std;
/*int main(){
    ofstream fout;
    char file[30];
    cout<<"Enter the file name to write in:";
    cin>>file;
    fout.open(file,ios::out); //jo phele likha hoga vo gayab ho jayega but in append mode it will add the upcoming data also
    
    int score;
    char pname[40];
    cout<<"Enter player name and score :"; 
    cin>>pname>>score;
    fout<<pname<<"\t"<<score<<endl; //writing in file
    fout.close();
    cout<<"\n Reading from file :\n";
    //Reading
    ifstream fin;
    fin.open(file,ios::in);
   
    while (!fin.eof()) { // end of  the loop will keep executing until there are no more characters left to read from the file
        char ch = fin.get();
        cout << ch;
    }
    fin.close();
    
    
}*/
class Filecopy{
    char src[30], des[30], ch;
    ofstream fout;
    ifstream fin;
public:
    void doFilecopy(){
        cout << "Enter the file name to read: ";
        cin.getline(src, 30);
        fin.open(src, ios::in);

        if(fin.fail()){
            cout << "File not found." << endl;
            return;
        }

        cout << "Enter the file name to write: ";
        cin.getline(des, 30);

        fout.open(des, ios::app);

        while (fin.get(ch)) { // Read the file character by character using fin.get(ch)
            fout << ch;
            cout << ch;
        }

        cout << "\nFile copied." << endl;

        fin.close();
        fout.close();
    }
};
int main(){
    Filecopy fc;
    fc.doFilecopy();
}