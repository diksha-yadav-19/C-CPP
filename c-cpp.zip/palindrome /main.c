#include <stdio.h>

int main()
{
    int N;
    int count = 0;

    printf("Enter N: ");
    scanf("%d", &N);

    printf("Palindrome Numbers Found:\n");

    for (int i = 1; i <= N; i++)
    {
        int reversedNum = 0;
        int originalNum = i;
        int num = i;

        while (num != 0)
        {
            int remainder = num % 10;
            reversedNum = reversedNum * 10 + remainder;
            num /= 10;
        }

        if (originalNum == reversedNum)
        {
            printf("Palindrome: %d\n", i);
            count++;
        }
    }

    printf("\nPalindrome Numbers Found: %d\n", count);

    return 0;
}

