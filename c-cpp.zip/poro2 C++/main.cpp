//poro passing object returning object
#include<iostream>
using namespace std;
class Person{
    int height;
    public:
    void setheight(int h){
        height=h;
    }
    void show(){
        cout<<"difference of height is :"<<height<<endl;
    }
   Person difference(Person p){
        Person diff;
        diff.height=height-p.height;
        return(diff);
    }
};
int main(){
  Person person1, person2;

    person1.setheight(160);
    person2.setheight(145);

   Person diffobj=person1.difference(person2);
   diffobj.show();
    return 0;
}
