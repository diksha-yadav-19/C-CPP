/******************************************************************************
STRINGS **
*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    char name[50]; 
    int count = 0; 

    cout << "Enter name of string:";
    //cin >> name;
     cin.getline(name, 50); // Read entire line including spaces into the name array

    
    for (int i = 0; name[i] != '\0'; i++) {
        count++;
    }

    cout << "The length of the string is: " << count << endl;

    return 0;
}
















































