#include<stdio.h>    
#include<stdlib.h>
    
    int main()
    {    
    struct FILE "RP","WP";
    char ch, sourcefile[25], targetfile[25];
    
    FILE *source, *des;    
    
    printf("Enter name of file to copy\n");
    gets(sourcefile);    
    
    source = fopen(sourcefile, "r");
    printf("Enter name of target file\n");
    
    gets(targetfile);
    
    des = fopen(targetfile, "w");
    
    if( des == NULL )
    {
        fclose(source);        
    }    
    
    while( ( ch = fgetc(source) ) != EOF )
        fputc(ch, des);
        
        printf("File copied successfully.\n");        
        fclose(source);        
        fclose(des);
        
        return 0;
}