#include<stdio.h>

int main(){
    int i,n,pro,price=0,ap,tp;
    printf("enter the products\n");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        printf("enter the value of %d product:\n",i);
        scanf("%d",&pro);
        tp=price+pro;
        ap=tp/n;

    }
printf("enter the total price=%d \n",tp);
printf("enter the average price=%d \n",ap);
    return 0;
}
        
    
