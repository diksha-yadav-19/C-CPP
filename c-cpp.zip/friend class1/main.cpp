#include<iostream>
using namespace std;
class Product{
    int qty;
    float price;
    public:
    void input(){
        cout<<"enter price and qty";
        cin>>price>>qty;
    }
    friend class Mall;
};
class Mall{
    float bill;
    public:
    void billing(Product lobj)
    {
        bill=lobj.price*lobj.qty;
        cout<<"\n Bill ="<<bill;
    }
};
int main(){
    Product lapobj;
    lapobj.input();
    Mall mmobj;
    mmobj.billing(lapobj);
}
