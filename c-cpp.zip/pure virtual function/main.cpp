#include <bits/stdc++.h>

using namespace std;
class Base 
{
    public: 
    virtual void func() = 0; // Pure Virtual Function
};

class Derived: public Base {
    public: 
    void func() 
    {
       cout << "Inside derived class" << endl;
    }
};
int main() {    
    // Base obj;
     Derived obj1;
     Base *ptr;
     ptr= &obj1;
     ptr->func();

    return 0;
}
