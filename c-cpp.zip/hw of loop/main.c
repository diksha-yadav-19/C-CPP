#include <stdio.h>

int main() {
    int n, i ,s,c;

    printf("Enter N: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
         s = i * i;
         c = i * i * i;
        printf("%d -> %d %d\n", i, s, c);
    }

    return 0;
}
