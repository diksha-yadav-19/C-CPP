#include <iostream>
#include <cmath>
using namespace std;

 
class Time
{
  
int hours, minutes, seconds;

 
public:
void settime (int h, int m, int s)
  {
    
hours = h;
    
minutes = m;
    
seconds = s;
  
} 
 
void show ()
  {
    
cout << hours << " hours " << minutes << " minutes " << seconds <<
      " seconds" << endl;
  
} 
 
Time operator- (Time obj)
  {
    
Time result;
    
int totalSeconds1 = hours * 3600 + minutes * 60 + seconds;
    
int totalSeconds2 = obj.hours * 3600 + obj.minutes * 60 + obj.seconds;
    
int diffSeconds = abs (totalSeconds1 - totalSeconds2);
    
 
result.hours = diffSeconds / 3600;
    
result.minutes = (diffSeconds % 3600) / 60;
    
result.seconds = diffSeconds % 60;
    
 
return result;
  
}

};


 
int
main ()
{
  
Time t1, t2;
  
int h, m, s;
  
 
cout << "Enter the time in hours, minutes, and seconds for t1: ";
  
cin >> h >> m >> s;
  
t1.settime (h, m, s);
  
cout << "t1: ";
  
t1.show ();
  
 
cout << "Enter the time in hours, minutes, and seconds for t2: ";
  
cin >> h >> m >> s;
  
t2.settime (h, m, s);
  
cout << "t2: ";
  
t2.show ();
  
 
Time t3;
  
t3 = t1 - t2;		// Using the overloaded '-' operator
  cout << "\nTime difference: ";
  
t3.show ();
  
 
return 0;

}


