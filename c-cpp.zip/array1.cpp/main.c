#include <stdio.h>

int main() {
    int N,count=0,count1=0,i;
    printf("Enter the number of students: ");
    scanf("%d", &N);

   
    int marks[N];
    for ( i = 0; i < N; i++) {
        printf("Enter Student whose is at marks[%d]: ", i );
        scanf("%d", &marks[i]);
    }


    for ( i = 0; i < N; i++) {
        if (marks[i] >= 80) {
            count++;
        } else if (marks[i] >= 60 && marks[i] <= 70) {
            count1++;
        }
    }


    printf("Number of students with >= 80 marks: %d\n", count);
    printf("Number of students with marks between 60 and 70: %d\n", count1);

    return 0;
}
