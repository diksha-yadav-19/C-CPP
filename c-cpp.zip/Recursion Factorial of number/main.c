
#include <stdio.h>

int main()
{
   int Factorial(int N);
   int fact,N;
   printf("enter a number");
   scanf("%d",&N);
   fact=Factorial(N);
   printf("Factorial of number is :%d\n",fact);
}
int Factorial(int N){
    if(N==1)
    return 1;
    int result=Factorial(N-1);
    int fact=N*result;
    return(fact);
}