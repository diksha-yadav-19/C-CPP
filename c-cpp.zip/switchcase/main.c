#include <stdio.h>


int main() {
    int choice;
    printf("Enter your choice:\n");
    scanf("%d", &choice);

    switch (choice) {
        case 2: {
            int num1, num2,max;
            printf("Enter two numbers: ");
            scanf("%d %d", &num1, &num2);
          max=(num1 > num2) ? num1 : num2;
            printf("Maximum number: %d\n", max);
            break;
        }
        case 3: {
            int num1, num2, num3,max;
            printf("Enter three numbers: ");
            scanf("%d %d %d", &num1, &num2, &num3);
          max = num1;
    if (num2 > max) {
        max = num2;
    }
    if (num3 > max) {
        max = num3;
    }
            printf("Maximum number: %d\n", max);
            break;
        }
        default:
            printf("Invalid choice!\n");
            break;
    }

    return 0;
}
