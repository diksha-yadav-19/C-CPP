#include <stdio.h>

int main() {
  void  findGreatest();
findGreatest();



}

void findGreatest() {
   
int num1, num2, greatest;

    printf("Enter the first number: ");
    scanf("%d", &num1);

    printf("Enter the second number: ");
    scanf("%d", &num2);
    
    if (num1 > num2) {
       printf("num1 is greatest");
    } else {
        printf("num2 is greatest");
    }
}

