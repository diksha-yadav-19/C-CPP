
#include <iostream>

using namespace std;

class Product{
    int price,qty;
    public:
    void input(){
        cout<<"enter the value for price and qty :";
        cin>>price>>qty;
    }
    void billing(){
        cout<<"\n BILL ="<<price*qty;
    }
};
int main(){
    Product *ptr=new Product();
    (*ptr).input();
    ptr->billing();
    delete ptr;
     ptr->billing();//Garbage value
    ptr=new Product();
}