#include <iostream>

using namespace std;

class Rect {
public:
    float length;
    float width;

    float getArea(float l, float w) {
        return l * w;
    }
};

class Circle : public Rect {
public:
    float radius;

    float getArea(float r) {
        return 3.14 * r * r;
    }
};

class Square : public Circle {
public:
    void area(float s) {
        float squareArea = getArea(s);
        cout << "Area of the Square: " << squareArea << endl;
    }
};

int main() {
    Square sobj;
    sobj.area(5);

    Circle cobj;
    float circleArea = cobj.getArea(10);
    cout << "Area of the Circle: " << circleArea << endl;

    Rect robj;
    float rectArea = robj.getArea(4, 6);
    cout << "Area of the Rectangle: " << rectArea << endl;
}

