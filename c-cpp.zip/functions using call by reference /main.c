#include <stdio.h>

int main() {
    void calculateSimpleInterest(float *P, float *R, float *T, float *SI);
    float principal, rate, time, interest;
    
    printf("Enter the principal amount: ");
    scanf("%f", &principal);
    
    printf("Enter the rate of interest: ");
    scanf("%f", &rate);
    
    printf("Enter the time period (in years): ");
    scanf("%f", &time);
    
    calculateSimpleInterest(&principal, &rate, &time, &interest);
    
    printf("\nSimple Interest: %f\n", interest);
}
void calculateSimpleInterest(float *P, float *R, float *T, float *SI) {
    *SI = (*P * *R * *T) / 100;
}
