#include <iostream>
#include <cmath>
using namespace std;

class Height {
    int feet, inches;

public:
   Height(int f=0, int i=0) { //Constructor 
        feet = f;
        inches = i;
    }

    void show() {
        cout << feet << "' " << inches << "'' ";
    }

    Height operator-(Height &obj) {
        Height result;
        int diff = abs((feet * 12 + inches) - (obj.feet * 12 + obj.inches));
        result.feet = diff / 12;
        result.inches = diff % 12;
        return result;
    }
};

int main() {
    Height p1(22,7), p2(8,4);


    Height p3 = p1 - p2;
     p3.show();

    return 0;
}

