#include <iostream>
using namespace std;

class College {
protected:
    float cfee;

public:

    void input1() {
        cout << "Enter college fee: ";
    cin >> cfee;
    }
};

class Traineer : public College {
protected:
    int tfee;

public:

    void input2() {
        cout << "Enter trainer fee: ";
        cin >> tfee;
    }
};

class Pocket {
protected:
    int money;

public:

    void input3() {
        cout << "Enter pocket money: ";
        cin >> money;
    }
};

class Total : public Traineer, public Pocket {

public:

    void calculate_total() {
        input1(); 
        input2(); 
        input3(); 

        float total_amount = cfee + tfee + money;
        cout<<"\n Total Amount is:"<<total_amount;
    }
};

int main() {
    Total total_obj;
    total_obj.calculate_total();

    return 0;
}


