
#include <iostream>

using namespace std;

class A{
    int x;
};
class B:public A{
    
};
int main()
{
    cout<<sizeof(int)<<endl;
    cout<<sizeof(A)<<endl;
     cout<<sizeof(B)<<endl;
    return 0;
}