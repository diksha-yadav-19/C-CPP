#include <iostream>

using namespace std;

class RECT {
    public:
    void rarea() {
        cout << "Area of Rect" << endl;
    }
};

class CIRCLE {
    public:
    void carea() {
        cout << "Area of Circle" << endl;
    }
};

class SQUARE {
    public:
    void sarea() {
        cout << "Area of square" << endl;
    }
};

class SHAPES : public CIRCLE, public SQUARE {
    public:
    void areas() {
        rarea();
        carea();
        sarea();
    }
};

int main(){
    SHAPES obj;
    obj.rarea();
    obj.areas();
}
