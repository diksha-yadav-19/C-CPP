// // matrix multiplication
// #include <stdio.h>

// int main()
// {
// int r,c,ra,rb,ca,cb,sum;
// printf("enter rows and columns of matrix A :");
// scanf("%d %d",&ra,&ca);
// printf("enter the rows and columns of matrix B: ");
// scanf("%d %d",&rb,&cb);
// if(ca!=rb){
//     printf("invalid number of rows and columns ");
//     return 0;
    
// }
// int A[ra][ca];
// for(r=0;r<ra;r++)
// {
//     for(c=0;c<ca;c++){
//         printf("enter the value at A[%d][%d]",r,c);
//         scanf("%d",&A[r][c]);
//     }
// }
// int B[rb][cb];
// for(r=0;r<rb;r++)
// {
//     for(c=0;c<cb;c++){
//         printf("enter the value at B[%d][%d]",r,c);
//         scanf("%d",&B[r][c]);
//     }
// }
// int C[ra][cb],uw;
// for(r=0;r<ra;r++)
// {
//     for(c=0;c<cb;c++){
//         sum=0;
//         for(uw=0;uw<ca;uw++){
//             sum=sum+A[r][uw]*B[uw][c];
//         }
//         C[r][c]=sum;
//     }
// }

//         printf("\n multiplied matrix");
//   for(r=0;r<ra;r++)
// {
//     for(c=0;c<cb;c++){
//         printf("enter the value at C[%d][%d]",r,c);
        
//     }
//     printf("\n");
// }     
//     return 0;
// }
#include <stdio.h>

int main()
{
    int r, c, ra, rb, ca, cb, sum;

    printf("Enter the number of rows and columns of matrix A: ");
    scanf("%d %d", &ra, &ca);

    printf("Enter the number of rows and columns of matrix B: ");
    scanf("%d %d", &rb, &cb);

    if (ca != rb) {
        printf("Invalid number of rows and columns for matrix multiplication.\n");
        return 0;
    }

    int A[ra][ca];

    for (r = 0; r < ra; r++) {
        for (c = 0; c < ca; c++) {
            printf("Enter the value at A[%d][%d]: ", r, c);
            scanf("%d", &A[r][c]);
        }
    }

    int B[rb][cb];

    for (r = 0; r < rb; r++) {
        for (c = 0; c < cb; c++) {
            printf("Enter the value at B[%d][%d]: ", r, c);
            scanf("%d", &B[r][c]);
        }
    }

    int C[ra][cb];

    for (r = 0; r < ra; r++) {
        for (c = 0; c < cb; c++) {
            sum = 0;
            for (int uw = 0; uw < ca; uw++) {
                sum += A[r][uw] * B[uw][c];
            }
            C[r][c] = sum;
        }
    }

    printf("\nMultiplied matrix:\n");

    for (r = 0; r < ra; r++) {
        for (c = 0; c < cb; c++) {
            printf("%d ", C[r][c]);
        }
        printf("\n");
    }

    return 0;
}
