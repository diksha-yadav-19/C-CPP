#include<iostream>
using namespace std;

class Tax;  // Forward declaration of the Tax class

class Salary {
    int sal;
public:
    void input() {
        cout << "Enter salary:";
        cin >> sal;
    }
    friend void show(Salary s, Tax t);
};

class Tax {
    int tax;
public:
    void input() {
        cout << "Enter tax:";
        cin >> tax;
    }
    friend void show(Salary s, Tax t);
};

void show(Salary s, Tax t) {
    float taxAmount = s.sal * (t.tax / 100.0);
    cout << "\nThe tax amount is: " << taxAmount;
}

int main() {
    Salary s;
    Tax t;

    s.input();
    t.input();

    show(s, t);

    return 0;
}





























































