#include<iostream>
#include<cmath>
using namespace std;

class Time {
    int hours, minutes;
public:
    void settime(int h, int m){
        hours = h;
        minutes = m;
    }

    void show(){
        cout << hours << " hours " << minutes << " minutes ";
    }

    Time diff(Time obj){
        Time result;
        int totalMinutes1 = hours * 60 + minutes;
        int totalMinutes2 = obj.hours * 60 + obj.minutes;
        int diffMinutes = abs(totalMinutes1 - totalMinutes2);

        result.hours = diffMinutes / 60;
        result.minutes = diffMinutes % 60;

        return result;
    }
};

int main(){
    Time t1, t2;
    int h, m;
    cout << "Enter the time in hours and minutes: ";
    cin >> h >> m;

    t1.settime(h, m);
    cout << "t1: ";
    t1.show();

    t2.settime(h, m);
    cout << "t2: ";
    t2.show();

    Time t3;
    t3 = t1.diff(t2);
    cout << "Time difference: ";
    t3.show();

    return 0;
}
