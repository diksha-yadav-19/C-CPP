
#include<iostream>
using namespace std;
class HEIGHT{
    int F,I;
    public:
    void setheight(int F1,int I1)
    {
        F=F1;
        I=I1;
    }
    int operator==(HEIGHT robj){
        if(F==robj.F & I==robj.I)
        return 1;
        else 
        return 0;
    }
    int operator < (HEIGHT robj){
        if((F*12+I)<(robj.F*12+robj.I))
        return 1;
        else
        return 0;
    }
};
int main(){
    HEIGHT amn,rmn;
    amn.setheight(5,6);
    rmn.setheight(5,6);
    if (amn == rmn)
        cout << "same" << endl;
    else
        cout << "\n not same\n";

    if (amn < rmn)
        cout << "Aman is shorter\n";
    else
        cout << "Raman is shorter";

    return 0;
}





















