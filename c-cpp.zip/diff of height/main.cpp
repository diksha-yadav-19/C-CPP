#include<iostream>
#include<cmath>
using namespace std;

class Height{
    int feet, inches;
public:
    void settime(int f, int i){
        feet = f;
        inches = i;
    }

    void show(){
        cout << feet << "' " << inches << "'' ";
    }

    Height party2(Height obj){
        Height bhai;
        int diff = abs((feet * 12 + inches) - (obj.feet * 12 + obj.inches));
        bhai.feet = diff / 12;
        bhai.inches = diff % 12;
        return bhai;
    }
};

int main(){
    Height p1, p2;
    int f, i;
    cout << "Enter the height in feet and inches of person1: ";
    cin >> f >> i;

    p1.settime(f, i);
   cout << "Enter the height in feet and inches of person2: ";
    cin >> f >> i;

    p2.settime(f, i);
    Height p3;
    p3 = p1.party2(p2);
    cout << "Difference: ";
    p3.show();

    return 0;
}

