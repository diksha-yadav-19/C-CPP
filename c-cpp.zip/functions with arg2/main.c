#include <stdio.h>
int main() {
    int reverseNumber(int num);
    int N;

    printf("Enter a number: ");
    scanf("%d", &N);

    int reversed = reverseNumber(N);

    printf("The reverse of the number is: %d\n", reversed);

}
int reverseNumber(int num) {
    int rev = 0;
    while (num > 0) {
        int digit = num % 10;
        rev = (rev * 10) + digit;
        num =num/ 10;
    }
    return rev;
}
