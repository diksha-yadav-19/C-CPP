#include <stdio.h>

// void Palindrome();

int main() {
  void Palindrome();
  Palindrome();

}

void Palindrome() {
    int n, temp, rem, rev, v;
    printf("Enter a number: ");
    scanf("%d", &n);
    
    for (v = 11; v <= n; v++) {
        rev = 0;
        temp = v;
        
        while (temp > 0) {
            rem = temp % 10;
            rev = rev * 10 + rem;
            temp = temp / 10;
        }
        
        printf("Reversed number of %d is = %d\n", v, rev);
        
        if (v == rev)
            printf("%d is a Palindrome Number\n", v);
        else
            printf("%d is not a Palindrome Number\n", v);
    }
}

