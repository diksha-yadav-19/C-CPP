#include <iostream>
using namespace std;

class SALARY
{
    
  float sal;
  public:
  void input()
  {
      cout<<"Enter salary=";
      cin>>sal;
  }
  
  float getSal()//getter
    {
        return sal;
    }
};

class SARKAR
    {
        float tax;
        public: 
        void calcTax(float sal)//setter
        {
            tax=sal*10/100;
            cout<<"\nTax="<<tax;
        }
    };

int main()
{
    SALARY sobj;
    sobj.input();
    float sal=sobj.getSal();
    SARKAR sar;
    sar.calcTax(sal);

    return 0;
}